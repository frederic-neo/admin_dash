import { hash } from 'bcrypt'
import { shared, env } from '@appblocks/node-sdk'
import otpTemp from './templates/otp-temp.js'
import hbs from 'hbs'
import validateSignupInput from './validation.js'
import { nanoid } from 'nanoid'

env.init()

const handler = async ({ req, res }) => {
  const {
    getBody,
    sendResponse,
    isEmpty,
    prisma,
    validateRequestMethod,
    checkHealth,
    generateRandomString,
    sendMail,
    redis,
    httpStatusCodes,
  } = await shared.getShared()

  try {
    // health check
    checkHealth(req, res)

    await validateRequestMethod(req, ['POST'])

    const requestBody = await getBody(req)

    if (isEmpty(requestBody)) {
      return sendResponse(res, 400, {
        message: 'Please provide the details',
      })
    }

    validateSignupInput(requestBody)

    const emailValid = await prisma.admin_users.findFirst({
      where: { email: requestBody.email },
    })

    if (emailValid) {
      return sendResponse(res, 400, {
        message: 'This email is already in use',
      })
    }

    const password = await hash(requestBody.password, 10)
    const adminu = {
      id: nanoid(),
      full_name: requestBody.first_name + requestBody.last_name,
      user_name: requestBody.first_name + requestBody.last_name,
      email: requestBody.email,
      password,
      role: 'admin',
      is_verified: false,
      created_at: new Date(),
      updated_at: new Date(),
    }
    console.log(adminu)

    const user = await prisma.admin_users.create({
      data: adminu,
    })

    const otp = generateRandomString()
    if (!redis.isOpen) await redis.connect()
    await redis.set(`${user.id}_otp`, otp, { EX: 600 })
    await redis.disconnect()

    const emailTemplate = hbs.compile(otpTemp)

    const message = {
      to: requestBody.email,
      from: {
        name: process.env.EMAIL_SENDER_NAME,
        email: process.env.SENDER_EMAIL_ID,
      },
      subject: 'verify otp',
      text: 'Please verify your otp',
      html: emailTemplate({
        // logo: null,
        user: requestBody.first_name,
        otp,
      }),
    }
    await sendMail(message)

    return sendResponse(res, 200, {
      message: 'OTP send to registered email',
    })
  } catch (e) {
    console.log('error:', JSON.stringify(e), e)
    const errorCode = e.errorCode || 500
    sendResponse(res, errorCode, {
      message: httpStatusCodes[errorCode],
    })
  }
}

export default handler
