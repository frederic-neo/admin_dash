export default {
  './auth_fe_login_layout': './src/remote/auth_fe_login_layout',
};
