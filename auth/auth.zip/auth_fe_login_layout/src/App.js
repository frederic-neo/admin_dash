import React from 'react';
import LoginLayout from './remote/login_layout';

export default function App() {
  return (
    <div className='App' data-testid='app'>
      <LoginLayout />
    </div>
  );
}
