const url_constants = {
  LOGIN: 'login',
  VERIFY_EMAIL: 'verify_email',
  RESET_PASSWORD: 'reset_password',
  FORGOT_PASSWORD: 'forgot_password',
  SIGNUP: 'signup',
  VERIFY_OTP: 'verify_otp',
}
export default url_constants
