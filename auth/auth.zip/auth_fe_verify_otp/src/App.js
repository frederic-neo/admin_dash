
import React from 'react'
import Auth_fe_verify_otp from './remote/auth_fe_verify_otp'

export default function App() {
  return (
    <div className="App" data-testid="app">
    <Auth_fe_verify_otp/>
    </div>
  )
}
