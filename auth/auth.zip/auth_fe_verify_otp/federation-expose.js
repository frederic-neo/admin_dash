export default {
    "./auth_fe_verify_otp": "./src/remote/auth_fe_verify_otp",
}