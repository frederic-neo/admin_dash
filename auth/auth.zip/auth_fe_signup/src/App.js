
import React from 'react'
import Auth_fe_signup from './remote/auth_fe_signup'

export default function App() {
  return (
    <div className="App" data-testid="app">
    <Auth_fe_signup/>
    </div>
  )
}
