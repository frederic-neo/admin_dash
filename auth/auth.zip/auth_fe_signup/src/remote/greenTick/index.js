import React from "react";
import tick from "../assets/img/icons/greentick.svg";

const GreenTick = () => {
  return <img src={tick} />;
};

export default GreenTick;
