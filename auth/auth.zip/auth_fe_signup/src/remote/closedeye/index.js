import React from "react";
import closedeye from "../assets/img/icons/closeeye.svg";

const ClosedEye = () => {
  return <img src={closedeye} />;
};

export default ClosedEye;
