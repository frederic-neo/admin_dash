import React from "react";
import errorCross from "../assets/img/icons/redclose.svg";

const ErrorCross = () => {
  return <img src={errorCross} />;
};

export default ErrorCross;
