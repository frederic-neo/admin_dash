import React from "react";
import openeye from "../assets/img/icons/openeye.svg";

const OpenEye = () => {
  return <img src={openeye} />;
};

export default OpenEye;
