export default {
    "./auth_fe_signup": "./src/remote/auth_fe_signup",
}