export default {
  "./auth_fe_reset_password": "./src/remote/auth_fe_reset_password",
};
