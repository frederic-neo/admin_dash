export default {
  "./auth_fe_login": "./src/remote/auth_fe_login",
};
