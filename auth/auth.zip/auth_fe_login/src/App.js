import React from 'react';
import Login from './remote/login';

export default function App() {
  return <Login />;
}
