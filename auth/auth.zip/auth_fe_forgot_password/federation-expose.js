export default {
  "./auth_fe_forgot_password": "./src/remote/auth_fe_forgot_password",
};
